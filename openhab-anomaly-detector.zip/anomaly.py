import pandas as pd
from sklearn.ensemble import IsolationForest

def detect_anomalies(payload):
    try:
        df = pd.DataFrame(payload['data'])
        model = IsolationForest(contamination=0.1)
        df['anomaly'] = model.fit_predict(df[['value']])
        anomalies = df[df['anomaly'] == -1]
        return {
            'status': 'ok',
            'anomalies': anomalies.to_dict(orient='records')
        }
    except Exception as e:
        return {
            'status': 'error',
            'message': str(e)
        }
