from flask import Flask, request, jsonify
from anomaly import detect_anomalies

app = Flask(__name__)

@app.route('/anomaly', methods=['POST'])
def anomaly_check():
    payload = request.json
    result = detect_anomalies(payload)
    return jsonify(result)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
